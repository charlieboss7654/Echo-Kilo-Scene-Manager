const app = document.getElementById('app');
const panelTitle = document.getElementById('panelTitle');
const panelBody = document.getElementById('panelBody');
const closeBtn = document.getElementById('closeBtn');
const backBtn = document.getElementById('backBtn');

const hint = document.getElementById('hint');
const hintTitle = document.getElementById('hintTitle');
const hintLines = document.getElementById('hintLines');

const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalDesc = document.getElementById('modalDesc');
const modalInput = document.getElementById('modalInput');
const modalCancel = document.getElementById('modalCancel');
const modalOk = document.getElementById('modalOk');

let stack = [];
let pages = {};
let pendingInput = null;

window.addEventListener('DOMContentLoaded', () => {
  nui('ready').catch(() => {});
});

function nui(action, data = {}) {
  return fetch(`https://${GetParentResourceName()}/${action}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data)
  });
}

function setVisible(v) {
  app.classList.toggle('hidden', !v);
}

function setBackVisible(v) {
  backBtn.classList.toggle('hidden', !v);
}

function renderPage(id) {
  const page = pages[id];
  if (!page) return;

  panelTitle.textContent = page.title || 'Scene Manager';
  setBackVisible(stack.length > 0);

  panelBody.innerHTML = '';
  (page.items || []).forEach(it => {
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <div class="card-title">${escapeHtml(it.title || '')}</div>
      <div class="card-desc">${escapeHtml(it.desc || '')}</div>
      ${it.tag ? `<div class="tag">${escapeHtml(it.tag)}</div>` : ``}
    `;
    el.addEventListener('click', () => {
      if (it.open) {
        stack.push(id);
        renderPage(it.open);
        nui('navigate', { page: it.open }).catch(() => {});
        return;
      }
      if (it.input) {
        openModal(it);
        return;
      }
      nui('action', { action: it.action, data: it.data || {} }).catch(() => {});
    });
    panelBody.appendChild(el);
  });
}

function openModal(item) {
  pendingInput = item;
  modalTitle.textContent = item.input.title || item.title || 'Input';
  modalDesc.textContent = item.input.desc || '';
  modalInput.value = item.input.default ?? '';
  if (typeof item.input.min === 'number') modalInput.min = String(item.input.min);
  else modalInput.removeAttribute('min');
  if (typeof item.input.max === 'number') modalInput.max = String(item.input.max);
  else modalInput.removeAttribute('max');
  modalInput.step = item.input.step ?? '1';
  modal.classList.remove('hidden');
  setTimeout(() => modalInput.focus(), 50);
}

function closeModal() {
  modal.classList.add('hidden');
  pendingInput = null;
}

modalCancel.addEventListener('click', () => closeModal());
modalOk.addEventListener('click', () => {
  if (!pendingInput) return;
  const val = modalInput.value === '' ? null : Number(modalInput.value);
  if (val === null || Number.isNaN(val)) return;

  nui('action', {
    action: pendingInput.action,
    data: { ...(pendingInput.data || {}), value: val }
  }).catch(() => {});
  closeModal();
});

closeBtn.addEventListener('click', () => {
  nui('close').catch(() => {});
  setVisible(false);
});

backBtn.addEventListener('click', () => {
  const prev = stack.pop();
  if (!prev) return;
  renderPage(prev);
  nui('navigate', { page: prev }).catch(() => {});
});

window.addEventListener('message', (e) => {
  const msg = e.data;
  if (!msg || !msg.type) return;

  if (msg.type === 'menu') {
    pages = msg.pages || {};
    stack = [];
    setVisible(!!msg.open);
    if (msg.open) {
      renderPage(msg.page || 'main');
    }
  }

  if (msg.type === 'hint') {
    const v = !!msg.visible;
    hint.classList.toggle('hidden', !v);
    if (v) {
      hintTitle.textContent = msg.title || '';
      hintLines.innerHTML = renderHint(msg.lines || []);
    }
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (!modal.classList.contains('hidden')) {
      closeModal();
      return;
    }
    nui('close').catch(() => {});
    setVisible(false);
  }
});


function renderHint(lines){
  const out = [];
  const known = [
    'CTRL + ARROWS',
    'CTRL+ARROWS',
    'CTRL + ARROW(OTATE)',
    'ARROWS',
    'BACKSPACE',
    'ENTER',
    'E'
  ];
  for (const raw of (lines || [])){
    const line = String(raw ?? '').trim();
    if (!line){
      out.push(`<div class="hint-sep"></div>`);
      continue;
    }

    const upper = line.toUpperCase();

    const pick = (key) => {
      const rest = line.slice(key.length).trim();
      return { key: key, rest };
    };

    let key = null;
    let rest = null;

    if (upper.startsWith('CTRL + ARROWS')) { ({key, rest} = pick('CTRL + Arrows')); }
    else if (upper.startsWith('CTRL+ARROWS')) { ({key, rest} = pick('CTRL+Arrows')); }
    else if (upper.startsWith('BACKSPACE')) { ({key, rest} = pick('Backspace')); }
    else if (upper.startsWith('ARROWS')) { ({key, rest} = pick('Arrows')); }
    else if (upper.startsWith('ENTER')) { ({key, rest} = pick('ENTER')); }
    else if (upper.startsWith('E ' ) || upper === 'E') { ({key, rest} = pick('E')); }
    else {
      const first = line.split(' ')[0];
      if (['E','ENTER','ARROWS','BACKSPACE'].includes(first.toUpperCase())){
        key = first;
        rest = line.slice(first.length).trim();
      }
    }

    if (key){
      out.push(
        `<div class="hint-row"><div class="hint-key">${escapeHtml(key)}</div><div class="hint-text">${escapeHtml(rest || '')}</div></div>`
      );
    } else {
      out.push(`<div class="hint-note">${escapeHtml(line)}</div>`);
    }
  }
  return out.join('');
}

function escapeHtml(s) {
  return String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}
