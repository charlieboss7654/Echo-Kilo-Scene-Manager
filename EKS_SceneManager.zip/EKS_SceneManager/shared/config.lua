Config = Config or {}

Config.Command = 'scenemanager'
Config.KeyMapping = {
    command = 'scenemanager',
    description = 'Open Scene Manager',
    defaultKey = 'F5'
}

Config.SpeedUnit = 'mph'

Config.Zone = {
    tickMs = 750,
    maxEntityScanDist = 220.0,
    secureZoneDeleteVehicles = true
}



Config.LaneControl = {
    enabled = true,
    markersNearby = 30,
    searchRadius = 90.0,
    closeRadius = 12.0,
    toggleKey = 191
}

Config.Blips = {
    showCentreBlip = true,
    centreSprite = 161,
    centreScale = 0.75,
    radiusAlpha = 80,
    radiusColours = {
        stop = 1,
        speed = 3,
        timed = 5,
        secure = 59
    }
}

Config.Controls = {
    placeConfirm = 38,
    placeCancel = 194,
    moveUp = 172,
    moveDown = 173,
    moveLeft = 174,
    moveRight = 175,
    rotateModifier = 36
}

Config.Placement = {
    step = 0.05,
    rotStep = 2.5,
    forwardOffset = 1.6,
    zOffset = -0.05
}

Config.Props = {
    TrafficControlEquipment = {
        { label = 'Cone', model = 'prop_roadcone02a' },
        { label = 'Cone (Large)', model = 'prop_roadcone01a' },
        { label = 'Barrier (Small)', model = 'prop_barrier_work06a' },
        { label = 'Barrier (Large)', model = 'prop_barrier_work05' },
        { label = 'Road Closed Sign', model = 'prop_sign_road_01a' }
    },

    SceneControlEquipment = {
        { label = 'Police Barrier', model = 'prop_barrier_work05' },
        { label = 'Flood Light', model = 'prop_worklight_03a' },
        { label = 'Generator', model = 'prop_generator_03b' },
        { label = 'Gazebo', model = 'prop_gazebo_03' }
    }
}
