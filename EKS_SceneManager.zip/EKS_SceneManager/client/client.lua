local Zones = {}
local Props = {}
local placing = false

local VehState = {}
local function vehKey(veh) return veh and veh ~= 0 and tostring(NetworkGetNetworkIdFromEntity(veh)) or nil end

local function unitToMS(v)
    if Config.SpeedUnit == 'mph' then
        return v * 0.44704
    end
    if Config.SpeedUnit == 'kph' then
        return v / 3.6
    end
    return v
end

local function notify(msg, typ)
    lib.notify({ description = msg, type = typ or 'inform' })
end

local function requestModel(model)
    local m = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(m) then return false end
    RequestModel(m)
    local t = GetGameTimer() + 5000
    while not HasModelLoaded(m) do
        Wait(0)
        if GetGameTimer() > t then
            return false
        end
    end
    return m
end

local function ensureControl(entity)
    if not DoesEntityExist(entity) then return false end
    if NetworkHasControlOfEntity(entity) then return true end
    NetworkRequestControlOfEntity(entity)
    local t = GetGameTimer() + 750
    while not NetworkHasControlOfEntity(entity) do
        Wait(0)
        NetworkRequestControlOfEntity(entity)
        if GetGameTimer() > t then
            break
        end
    end
    return NetworkHasControlOfEntity(entity)
end

local function clearZoneBlips(z)
    if z.blipRadius and DoesBlipExist(z.blipRadius) then RemoveBlip(z.blipRadius) end
    if z.blipCentre and DoesBlipExist(z.blipCentre) then RemoveBlip(z.blipCentre) end
    z.blipRadius = nil
    z.blipCentre = nil
end

local function applyZoneBlips(z)
    clearZoneBlips(z)
    local col = (Config.Blips.radiusColours[z.type] or 1)
    z.blipRadius = AddBlipForRadius(z.center.x + 0.0, z.center.y + 0.0, z.center.z + 0.0, z.radius + 0.0)
    SetBlipColour(z.blipRadius, col)
    SetBlipAlpha(z.blipRadius, Config.Blips.radiusAlpha or 80)

    if Config.Blips.showCentreBlip then
        z.blipCentre = AddBlipForCoord(z.center.x + 0.0, z.center.y + 0.0, z.center.z + 0.0)
        SetBlipSprite(z.blipCentre, Config.Blips.centreSprite or 161)
        SetBlipScale(z.blipCentre, Config.Blips.centreScale or 0.75)
        SetBlipColour(z.blipCentre, col)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString('Scene Zone')
        EndTextCommandSetBlipName(z.blipCentre)
    end
end

local function upsertZone(zone)
    Zones[zone.id] = zone
    applyZoneBlips(Zones[zone.id])
end

local function removeZone(id)
    local z = Zones[id]
    if not z then return end
    clearZoneBlips(z)
    Zones[id] = nil
end

local function getNearestZoneOwned()
    local ped = PlayerPedId()
    local p = GetEntityCoords(ped)
    local bestId, bestD = nil, 1e9
    for id, z in pairs(Zones) do
        if z.owner == cache.serverId then
            local d = #(p - vector3(z.center.x, z.center.y, z.center.z))
            if d < bestD then
                bestD = d
                bestId = id
            end
        end
    end
    return bestId, bestD
end

local function getNearestPropOwned()
    local ped = PlayerPedId()
    local p = GetEntityCoords(ped)
    local bestId, bestD = nil, 1e9
    for id, pr in pairs(Props) do
        if pr.owner == cache.serverId then
            local d = #(p - vector3(pr.coords.x, pr.coords.y, pr.coords.z))
            if d < bestD then
                bestD = d
                bestId = id
            end
        end
    end
    return bestId, bestD
end

local showHint, hideHint

local function drawHelpText(lines)
    showHint(lines[1] or '', { lines[2] or '', lines[3] or '', lines[4] or '', lines[5] or '', lines[6] or '', lines[7] or '', lines[8] or '', lines[9] or '' })
end

local function endHelpText()
    hideHint()
end

local function createZone(typeName, radius, speed, duration)
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    TriggerServerEvent('eks_scenemanager:zoneCreate', {
        type = typeName,
        center = { x = c.x, y = c.y, z = c.z },
        radius = radius,
        speed = speed,
        duration = duration
    })
end

local function promptNumber(title, desc, min, max, default)
    local input = lib.inputDialog(title, {
        { type = 'number', label = desc, min = min, max = max, default = default }
    })
    if not input or input[1] == nil then return nil end
    return tonumber(input[1])
end

local nuiOpen = false
local currentPage = 'main'

local nuiReady = false
local pendingMenu = nil

local function nuiSend(typeName, payload)
    local msg = payload or {}
    msg.type = typeName
    SendNUIMessage(msg)
end

local function openNui(page)
    if nuiOpen then return end
    nuiOpen = true
    currentPage = page or 'main'
    SetNuiFocus(true, true)

    local pages = {
        main = {
            title = 'Scene Manager',
            items = {
                { title = 'Traffic Manager', desc = 'Traffic zones, lane management', open = 'traffic', tag = 'Zones' },
                { title = 'Traffic Control Equipment', desc = 'Cones, barriers and traffic props', open = 'tce', tag = 'Props' },
                { title = 'Scene Control Equipment', desc = 'Scene props and equipment', open = 'sce', tag = 'Props' }
            }
        },
        traffic = {
            title = 'Traffic Manager',
            items = {
                { title = 'Stop Traffic', desc = 'Create a stop traffic zone radius', action = 'stop_radius', input = { title = 'Stop Traffic', desc = 'Radius metres', min = 5, max = 300, default = 35, step = 1 } },
                { title = 'Set Traffic Speed', desc = 'Set AI cruising speed speed + radius', action = 'speed_speed', input = { title = 'Set Traffic Speed', desc = 'Speed ('..Config.SpeedUnit..')', min = 0, max = 120, default = 20, step = 1 } },
                { title = 'Timed Traffic Zone', desc = 'Speed zone that deletes after a timer', action = 'timed_speed', input = { title = 'Timed Traffic Zone', desc = 'Speed ('..Config.SpeedUnit..')', min = 0, max = 120, default = 20, step = 1 } },
                { title = 'Set Secure Zone', desc = 'Peds flee; NPC vehicles deleted when entering', action = 'secure_radius', input = { title = 'Secure Zone', desc = 'Radius metres', min = 5, max = 300, default = 35, step = 1 } },
                { title = 'Lane Management', desc = 'Toggle road elements open/closed AI avoid closed', action = 'lane_toggle' },
                { title = 'Delete Nearest Zone', desc = 'Deletes your nearest zone', action = 'zone_delete_nearest' },
                { title = 'Delete All Zones', desc = 'Deletes all of your zones', action = 'zone_delete_all' }
            }
        },
        tce = { title = 'Traffic Control Equipment', items = {} },
        sce = { title = 'Scene Control Equipment', items = {} }
    }

    for i = 1, #Config.Props.TrafficControlEquipment do
        local it = Config.Props.TrafficControlEquipment[i]
        pages.tce.items[#pages.tce.items + 1] = {
            title = 'Place '..it.label,
            desc = 'Place prop with hologram controls',
            action = 'prop_place',
            data = { category = 'Traffic Control Equipment', label = it.label, model = it.model }
        }
    end
    pages.tce.items[#pages.tce.items + 1] = { title = 'Delete Nearest Prop', desc = 'Deletes your nearest placed prop', action = 'prop_delete_nearest' }
    pages.tce.items[#pages.tce.items + 1] = { title = 'Delete All Props', desc = 'Deletes all of your placed props', action = 'prop_delete_all' }

    for i = 1, #Config.Props.SceneControlEquipment do
        local it = Config.Props.SceneControlEquipment[i]
        pages.sce.items[#pages.sce.items + 1] = {
            title = 'Place '..it.label,
            desc = 'Place prop with hologram controls',
            action = 'prop_place',
            data = { category = 'Scene Control Equipment', label = it.label, model = it.model }
        }
    end
    pages.sce.items[#pages.sce.items + 1] = { title = 'Delete Nearest Prop', desc = 'Deletes your nearest placed prop', action = 'prop_delete_nearest' }
    pages.sce.items[#pages.sce.items + 1] = { title = 'Delete All Props', desc = 'Deletes all of your placed props', action = 'prop_delete_all' }

    pendingMenu = { type = 'menu', open = true, page = currentPage, pages = pages }
    if nuiReady then
        SendNUIMessage(pendingMenu)
    end
end

local function closeNui()
    if not nuiOpen then return end
    nuiOpen = false
    SetNuiFocus(false, false)
    pendingMenu = { type = 'menu', open = false }
    if nuiReady then
        SendNUIMessage(pendingMenu)
    end
end

RegisterNUICallback('ready', function(_, cb)
    nuiReady = true
    if pendingMenu then
        SendNUIMessage(pendingMenu)
    end
    cb(true)
end)

RegisterNUICallback('close', function(_, cb)
    closeNui()
    cb(true)
end)

RegisterNUICallback('navigate', function(data, cb)
    if data and data.page then currentPage = tostring(data.page) end
    cb(true)
end)

local function beginPlacementFlow(propLabel, propModel, categoryName)
    if placing then return end
    local m = requestModel(propModel)
    if not m then
        notify('Invalid prop model.', 'error')
        return
    end

    placing = true

    local ped = PlayerPedId()
    local p = GetEntityCoords(ped)
    local f = GetEntityForwardVector(ped)
    local start = vector3(
        p.x + f.x * Config.Placement.forwardOffset,
        p.y + f.y * Config.Placement.forwardOffset,
        p.z + Config.Placement.zOffset
    )

    local obj = CreateObject(m, start.x, start.y, start.z, true, true, false)
    SetEntityAlpha(obj, 170, false)
    SetEntityCollision(obj, false, false)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)

    local pedHeading = GetEntityHeading(ped)
    local baseForward = Config.Placement.forwardOffset + 0.0

    local offset = vector3(0.0, 0.0, 0.0)
    local rot = vector3(0.0, 0.0, pedHeading + 0.0)

    local lines = {
        ('%s - %s'):format(categoryName, propLabel),
        '',
        'E  Place',
        'Backspace  Cancel',
        '',
        'Arrows  Adjust (Left/Right/Up/Down)',
        'CTRL + Arrows  Rotate',
        '',
        'Walk to reposition'
    }
    drawHelpText(lines)

    while placing do
        Wait(0)

        ped = PlayerPedId()
        local p2 = GetEntityCoords(ped)
        local f2 = GetEntityForwardVector(ped)

        local base = vector3(
            p2.x + f2.x * baseForward,
            p2.y + f2.y * baseForward,
            p2.z + Config.Placement.zOffset
        )

        local step = Config.Placement.step
        local rstep = Config.Placement.rotStep
        local ctrl = IsControlPressed(0, Config.Controls.rotateModifier)

        if IsControlJustPressed(0, Config.Controls.placeCancel) then
            placing = false
            break
        end

        if IsControlJustPressed(0, Config.Controls.placeConfirm) then
            placing = false
            break
        end

        if ctrl then
            if IsControlPressed(0, Config.Controls.moveLeft) then rot = vector3(rot.x, rot.y, rot.z + rstep) end
            if IsControlPressed(0, Config.Controls.moveRight) then rot = vector3(rot.x, rot.y, rot.z - rstep) end
            if IsControlPressed(0, Config.Controls.moveUp) then rot = vector3(rot.x + rstep, rot.y, rot.z) end
            if IsControlPressed(0, Config.Controls.moveDown) then rot = vector3(rot.x - rstep, rot.y, rot.z) end
        else
            if IsControlPressed(0, Config.Controls.moveLeft) then offset = vector3(offset.x - step, offset.y, offset.z) end
            if IsControlPressed(0, Config.Controls.moveRight) then offset = vector3(offset.x + step, offset.y, offset.z) end
            if IsControlPressed(0, Config.Controls.moveUp) then offset = vector3(offset.x, offset.y, offset.z + step) end
            if IsControlPressed(0, Config.Controls.moveDown) then offset = vector3(offset.x, offset.y, offset.z - step) end
        end

        local final = vector3(base.x + offset.x, base.y + offset.y, base.z + offset.z)

        SetEntityCoordsNoOffset(obj, final.x, final.y, final.z, false, false, false)
        SetEntityRotation(obj, rot.x, rot.y, rot.z, 2, true)
    end

    endHelpText()

    if not DoesEntityExist(obj) then return end

    local placed = IsControlJustPressed(0, Config.Controls.placeConfirm)
    local finalPos = GetEntityCoords(obj)
    local finalRot = GetEntityRotation(obj, 2)

    ResetEntityAlpha(obj)
    SetEntityCollision(obj, true, true)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)

    if not placed then
        if ensureControl(obj) then
            DeleteEntity(obj)
        else
            DeleteObject(obj)
        end
        return
    end

    local netId = NetworkGetNetworkIdFromEntity(obj)
    TriggerServerEvent('eks_scenemanager:propRegister', {
        label = propLabel,
        model = propModel,
        netId = netId,
        coords = { x = finalPos.x, y = finalPos.y, z = finalPos.z },
        rot = { x = finalRot.x, y = finalRot.y, z = finalRot.z }
    })
end

RegisterNUICallback('action', function(payload, cb)
    local action = payload and payload.action
    local data = payload and payload.data or {}
    if action == 'stop_radius' then
        local r = tonumber(data.value)
        if r then createZone('stop', r, nil, nil) end
    elseif action == 'speed_speed' then
        local s = tonumber(data.value)
        if s == nil then cb(true) return end
        closeNui()
        local r = promptNumber('Set Traffic Speed', 'Radius (metres)', 5, 300, 60)
        if r then createZone('speed', r, s, nil) end
    elseif action == 'timed_speed' then
        local s = tonumber(data.value)
        if s == nil then cb(true) return end
        closeNui()
        local r = promptNumber('Timed Traffic Zone', 'Radius (metres)', 5, 300, 60)
        if not r then cb(true) return end
        local t = promptNumber('Timed Traffic Zone', 'Time (seconds)', 5, 3600, 60)
        if t then createZone('timed', r, s, t) end
    elseif action == 'secure_radius' then
        local r = tonumber(data.value)
        if r then createZone('secure', r, nil, nil) end
    elseif action == 'lane_toggle' then
        closeNui()
        TriggerEvent('eks_scenemanager:laneControlToggle')
    elseif action == 'zone_delete_nearest' then
        local id, d = getNearestZoneOwned()
        if not id or d > 150.0 then
            notify('No nearby zone found.', 'error')
        else
            TriggerServerEvent('eks_scenemanager:zoneDelete', id)
        end
    elseif action == 'zone_delete_all' then
        TriggerServerEvent('eks_scenemanager:zoneDeleteAll')
    elseif action == 'prop_place' then
        closeNui()
        if data and data.model and data.label and data.category then
            beginPlacementFlow(data.label, data.model, data.category)
        end
    elseif action == 'prop_delete_nearest' then
        local id, d = getNearestPropOwned()
        if not id or d > 50.0 then
            notify('No nearby prop found.', 'error')
        else
            TriggerServerEvent('eks_scenemanager:propDelete', id)
        end
    elseif action == 'prop_delete_all' then
        TriggerServerEvent('eks_scenemanager:propDeleteAll')
    end
    cb(true)
end)

showHint = function(title, lines)
    SendNUIMessage({ type = 'hint', visible = true, title = title or '', lines = lines or {} })
end

hideHint = function()
    SendNUIMessage({ type = 'hint', visible = false })
end

RegisterCommand(Config.Command, function()
    openNui('main')
end, false)

RegisterKeyMapping(Config.KeyMapping.command, Config.KeyMapping.description, 'keyboard', Config.KeyMapping.defaultKey)

RegisterNetEvent('eks_scenemanager:syncAll', function(payload)
    for id, z in pairs(Zones) do
        clearZoneBlips(z)
    end
    Zones = {}
    Props = {}

    if payload and payload.zones then
        for _, zone in ipairs(payload.zones) do
            upsertZone(zone)
        end
    end

    if payload and payload.props then
        for _, pr in ipairs(payload.props) do
            Props[pr.id] = pr
        end
    end
end)

RegisterNetEvent('eks_scenemanager:zoneUpsert', function(zone)
    if not zone or not zone.id then return end
    upsertZone(zone)
end)

RegisterNetEvent('eks_scenemanager:zoneRemove', function(id)
    removeZone(id)
end)

RegisterNetEvent('eks_scenemanager:propUpsert', function(pr)
    if not pr or not pr.id then return end
    Props[pr.id] = pr
end)

RegisterNetEvent('eks_scenemanager:propRemove', function(id)
    Props[id] = nil
end)

CreateThread(function()
    Wait(1000)
    TriggerServerEvent('eks_scenemanager:requestSync')
end)

local function isPlayerPed(ped)
    if not DoesEntityExist(ped) then return false end
    return IsPedAPlayer(ped)
end

local function npcDriver(veh)
    if not DoesEntityExist(veh) then return nil end
    local driver = GetPedInVehicleSeat(veh, -1)
    if driver == 0 or not DoesEntityExist(driver) then return nil end
    if isPlayerPed(driver) then return nil end
    return driver
end

local function hasAnyPlayerOccupant(veh)
    local max = GetVehicleMaxNumberOfPassengers(veh)
    for i = -1, max do
        local p = GetPedInVehicleSeat(veh, i)
        if p ~= 0 and DoesEntityExist(p) and isPlayerPed(p) then
            return true
        end
    end
    return false
end

local function applyStopTraffic(veh, driver)
    SetVehicleHandbrake(veh, true)
    SetVehicleMaxSpeed(veh, 0.0)
    SetDriveTaskCruiseSpeed(driver, 0.0)
    BringVehicleToHalt(veh, 0.0, 1, true)
    SetVehicleForwardSpeed(veh, 0.0)
    SetEntityVelocity(veh, 0.0, 0.0, 0.0)
    TaskVehicleTempAction(driver, veh, 27, 1000)
end

local function applySpeed(veh, driver, speedMS)
    SetVehicleHandbrake(veh, false)
    SetVehicleMaxSpeed(veh, speedMS)
    SetDriveTaskCruiseSpeed(driver, speedMS)
    SetDriverAbility(driver, 1.0)
    SetDriverAggressiveness(driver, 0.0)
end

local function applySecurePed(ped, zoneCenter)
    if not DoesEntityExist(ped) then return end
    if isPlayerPed(ped) then return end
    if IsPedInAnyVehicle(ped, false) then return end
    TaskSmartFleeCoord(ped, zoneCenter.x, zoneCenter.y, zoneCenter.z, 250.0, -1, false, false)
end

local function deleteEntity(entity)
    if not DoesEntityExist(entity) then return end
    if not ensureControl(entity) then return end
    SetEntityAsMissionEntity(entity, true, true)
    DeleteEntity(entity)
end


local function resetVehicle(veh)
    if not DoesEntityExist(veh) then return end
    SetVehicleMaxSpeed(veh, 0.0)
    SetVehicleHandbrake(veh, false)
end

CreateThread(function()
    while true do
        Wait(Config.Zone.tickMs)

        local ped = PlayerPedId()
        local p = GetEntityCoords(ped)
        local scanDist = Config.Zone.maxEntityScanDist or 220.0
        local scanDist2 = scanDist * scanDist

        local vehicles = GetGamePool('CVehicle')
        local peds = GetGamePool('CPed')

        local touched = {}

        for _, z in pairs(Zones) do
            local center = vector3(z.center.x, z.center.y, z.center.z)
            local r = z.radius + 0.0
            local r2 = r * r

            if #(p - center) <= (scanDist + r) then
                for i = 1, #vehicles do
                    local veh = vehicles[i]
                    if DoesEntityExist(veh) then
                        local vc = GetEntityCoords(veh)
                        local dp = vc - p
                        if (dp.x*dp.x + dp.y*dp.y + dp.z*dp.z) <= scanDist2 then
                            local dz = vc - center
                            if (dz.x*dz.x + dz.y*dz.y + dz.z*dz.z) <= r2 then
                                local driver = npcDriver(veh)
                                if driver then
                                    local nk = vehKey(veh)
                                    if nk then touched[nk] = veh end

                                    if z.type == 'stop' then
                                        applyStopTraffic(veh, driver)
                                    elseif z.type == 'speed' or z.type == 'timed' then
                                        local sp = unitToMS(tonumber(z.speed or 0) or 0)
                                        applySpeed(veh, driver, sp)
                                    elseif z.type == 'secure' and Config.Zone.secureZoneDeleteVehicles then
                                        if not hasAnyPlayerOccupant(veh) then
                                            local max = GetVehicleMaxNumberOfPassengers(veh)
                                            for s = -1, max do
                                                local occ = GetPedInVehicleSeat(veh, s)
                                                if occ ~= 0 and DoesEntityExist(occ) and not isPlayerPed(occ) then
                                                    deleteEntity(occ)
                                                end
                                            end
                                            deleteEntity(veh)
                                        end
                                    end
                                end
                            end
                        end
                    end
                end

                if z.type == 'secure' then
                    for i = 1, #peds do
                        local pd = peds[i]
                        if DoesEntityExist(pd) and pd ~= ped then
                            local pc = GetEntityCoords(pd)
                            local dp = pc - p
                            if (dp.x*dp.x + dp.y*dp.y + dp.z*dp.z) <= scanDist2 then
                                local dz = pc - center
                                if (dz.x*dz.x + dz.y*dz.y + dz.z*dz.z) <= r2 then
                                    applySecurePed(pd, center)
                                end
                            end
                        end
                    end
                end
            end
        end

        for k, st in pairs(VehState) do
            if not touched[k] then
                local veh = st.veh
                if veh and DoesEntityExist(veh) then
                    resetVehicle(veh)
                end
                VehState[k] = nil
            end
        end

        for k, veh in pairs(touched) do
            VehState[k] = { veh = veh }
        end
    end
end)


RegisterNetEvent('eks_scenemanager:deleteNetEntity', function(netId)
    netId = tonumber(netId)
    if not netId then return end
    local ent = NetworkGetEntityFromNetworkId(netId)
    if ent and ent ~= 0 and DoesEntityExist(ent) then
        if ensureControl(ent) then
            SetEntityAsMissionEntity(ent, true, true)
            DeleteEntity(ent)
        end
    end
end)


local LaneBlocks = {}
local laneMode = false

local function laneKey(c)
    return ('%.2f:%.2f:%.2f'):format(c.x, c.y, c.z)
end

local function setRoadClosedAt(c, r, closed)
    local x1, y1, z1 = c.x - r, c.y - r, c.z - 15.0
    local x2, y2, z2 = c.x + r, c.y + r, c.z + 15.0
    if closed then
        SetRoadsInArea(x1, y1, z1, x2, y2, z2, false, false)
    else
        SetRoadsInArea(x1, y1, z1, x2, y2, z2, true, true)
    end
end
local function applyLaneSpeedZone(c, enabled)
    if not c then return nil end
    if enabled then
        local radius = Config.LaneControl.closeRadius or 12.0
        return AddRoadNodeSpeedZone(c.x + 0.0, c.y + 0.0, c.z + 0.0, radius + 0.0, 0.0, false)
    end
    return nil
end


RegisterNetEvent('eks_scenemanager:laneSync', function(list)
    for _, it in pairs(LaneBlocks) do
        if it and it.zoneId then
            RemoveRoadNodeSpeedZone(it.zoneId)
        end
        if it and it.coords then
            local c = vector3(it.coords.x, it.coords.y, it.coords.z)
            setRoadClosedAt(c, Config.LaneControl.closeRadius, false)
        end
    end

    LaneBlocks = {}
    if type(list) == 'table' then
        for _, it in ipairs(list) do
            if it and it.coords then
                local c = vector3(it.coords.x, it.coords.y, it.coords.z)
                local k = laneKey(c)
                LaneBlocks[k] = { coords = { x = c.x, y = c.y, z = c.z }, closed = it.closed and true or false, zoneId = nil }
                setRoadClosedAt(c, Config.LaneControl.closeRadius, LaneBlocks[k].closed)
                if LaneBlocks[k].closed then
                    LaneBlocks[k].zoneId = applyLaneSpeedZone(c, true)
                end
            end
        end
    end
end)

RegisterNetEvent('eks_scenemanager:laneUpsert', function(it)
    if not it or not it.coords then return end
    local c = vector3(it.coords.x, it.coords.y, it.coords.z)
    local k = laneKey(c)

    if LaneBlocks[k] and LaneBlocks[k].zoneId then
        RemoveRoadNodeSpeedZone(LaneBlocks[k].zoneId)
    end

    LaneBlocks[k] = { coords = { x = c.x, y = c.y, z = c.z }, closed = it.closed and true or false, zoneId = nil }
    setRoadClosedAt(c, Config.LaneControl.closeRadius, LaneBlocks[k].closed)
    if LaneBlocks[k].closed then
        LaneBlocks[k].zoneId = applyLaneSpeedZone(c, true)
    end
end)

RegisterNetEvent('eks_scenemanager:laneRemove', function(coords)
    if not coords then return end
    local c = vector3(coords.x, coords.y, coords.z)
    local k = laneKey(c)
    local prev = LaneBlocks[k]
    if prev then
        if prev.zoneId then
            RemoveRoadNodeSpeedZone(prev.zoneId)
        end
        setRoadClosedAt(c, Config.LaneControl.closeRadius, false)
        LaneBlocks[k] = nil
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, it in pairs(LaneBlocks) do
        if it and it.zoneId then
            RemoveRoadNodeSpeedZone(it.zoneId)
        end
        if it and it.coords then
            local c = vector3(it.coords.x, it.coords.y, it.coords.z)
            setRoadClosedAt(c, Config.LaneControl.closeRadius, false)
        end
    end
end)

RegisterNetEvent('eks_scenemanager:laneControlToggle', function()
    if not Config.LaneControl.enabled then return end
    laneMode = not laneMode
    if laneMode then
        showHint('Lane Management', { 'ENTER  Toggle', 'Backspace  Exit', '', 'Green = Open', 'Red = Closed' })
    else
        hideHint()
    end
end)

CreateThread(function()
    while true do
        if not laneMode then
            Wait(250)
        else
            Wait(0)
            local ped = PlayerPedId()
            local p = GetEntityCoords(ped)

            local nodes = {}
            local count = math.min(Config.LaneControl.markersNearby or 30, 60)
            local r = Config.LaneControl.searchRadius or 90.0

            for i = 1, count do
                local ok, outPos = GetNthClosestVehicleNode(p.x, p.y, p.z, i, 1, 3.0, 0.0)
                if ok then
                    local c = vector3(outPos.x, outPos.y, outPos.z)
                    if #(p - c) <= r then
                        nodes[#nodes+1] = c
                    end
                end
            end

            local nearest, nd = nil, 1e9
            for i = 1, #nodes do
                local c = nodes[i]
                local d = #(p - c)
                if d < nd then
                    nd = d
                    nearest = c
                end
                local k = laneKey(c)
                local closed = LaneBlocks[k] and LaneBlocks[k].closed or false
                DrawMarker(1, c.x, c.y, c.z + 0.2, 0.0,0.0,0.0, 0.0,0.0,0.0, 1.2,1.2,0.6, closed and 255 or 0, closed and 0 or 255, 0, 90, false, true, 2, false, nil, nil, false)
            end

            if IsControlJustPressed(0, 194) then
                laneMode = false
                hideHint()
            end

            if nearest and nd <= 3.0 and IsControlJustPressed(0, Config.LaneControl.toggleKey) then
                local k = laneKey(nearest)
                local closed = not (LaneBlocks[k] and LaneBlocks[k].closed or false)
                TriggerServerEvent('eks_scenemanager:laneToggle', { x = nearest.x, y = nearest.y, z = nearest.z }, closed)
            end
        end
    end
end)