local Zones = {}
local Props = {}
local LaneBlocks = {}
local zoneSeq = 0
local propSeq = 0

local function broadcast(evt, ...)
    TriggerClientEvent(evt, -1, ...)
end

local function packAll()
    local z = {}
    for _, v in pairs(Zones) do z[#z+1] = v end
    local p = {}
    for _, v in pairs(Props) do p[#p+1] = v end
    local lb = {}
    for _, v in pairs(LaneBlocks) do lb[#lb+1] = v end
    return { zones = z, props = p, lanes = lb }
end

RegisterNetEvent('eks_scenemanager:requestSync', function()
    local src = source
    local payload = packAll()
    TriggerClientEvent('eks_scenemanager:syncAll', src, payload)
    TriggerClientEvent('eks_scenemanager:laneSync', src, payload.lanes)
end)

RegisterNetEvent('eks_scenemanager:zoneCreate', function(data)
    local src = source
    if type(data) ~= 'table' then return end
    if type(data.center) ~= 'table' then return end

    local typeName = tostring(data.type or '')
    if typeName ~= 'stop' and typeName ~= 'speed' and typeName ~= 'timed' and typeName ~= 'secure' then
        return
    end

    local radius = tonumber(data.radius or 0) or 0
    if radius < 1 or radius > 600 then return end

    local speed = tonumber(data.speed or 0)
    local duration = tonumber(data.duration or 0)

    zoneSeq = zoneSeq + 1
    local id = zoneSeq

    local zone = {
        id = id,
        owner = src,
        type = typeName,
        center = { x = data.center.x + 0.0, y = data.center.y + 0.0, z = data.center.z + 0.0 },
        radius = radius + 0.0,
        speed = speed and (speed + 0.0) or nil,
        createdAt = os.time()
    }

    Zones[id] = zone
    broadcast('eks_scenemanager:zoneUpsert', zone)

    if typeName == 'timed' then
        if not duration or duration < 1 or duration > 86400 then duration = 60 end
        local expireId = id
        SetTimeout(math.floor(duration * 1000), function()
            if Zones[expireId] then
                local z = Zones[expireId]
                Zones[expireId] = nil
                broadcast('eks_scenemanager:zoneRemove', expireId)
            end
        end)
    end
end)

RegisterNetEvent('eks_scenemanager:zoneDelete', function(id)
    local src = source
    id = tonumber(id)
    local z = id and Zones[id]
    if not z then return end
    if z.owner ~= src then return end
    Zones[id] = nil
    broadcast('eks_scenemanager:zoneRemove', id)
end)

RegisterNetEvent('eks_scenemanager:zoneDeleteAll', function()
    local src = source
    local removed = {}
    for id, z in pairs(Zones) do
        if z.owner == src then
            removed[#removed+1] = id
        end
    end
    for i = 1, #removed do
        Zones[removed[i]] = nil
        broadcast('eks_scenemanager:zoneRemove', removed[i])
    end
end)

RegisterNetEvent('eks_scenemanager:propRegister', function(data)
    local src = source
    if type(data) ~= 'table' then return end
    if not data.netId or not data.model then return end

    propSeq = propSeq + 1
    local id = propSeq

    Props[id] = {
        id = id,
        owner = src,
        label = tostring(data.label or 'Prop'),
        model = tostring(data.model),
        netId = tonumber(data.netId),
        coords = data.coords,
        rot = data.rot
    }

    broadcast('eks_scenemanager:propUpsert', Props[id])
end)

RegisterNetEvent('eks_scenemanager:propDelete', function(id)
    local src = source
    id = tonumber(id)
    local pr = id and Props[id]
    if not pr then return end
    if pr.owner ~= src then return end

    local netId = pr.netId
    Props[id] = nil
    broadcast('eks_scenemanager:propRemove', id)
    broadcast('eks_scenemanager:deleteNetEntity', netId)
end)

RegisterNetEvent('eks_scenemanager:propDeleteAll', function()
    local src = source
    local removed = {}
    for id, pr in pairs(Props) do
        if pr.owner == src then
            removed[#removed+1] = id
        end
    end

    for i = 1, #removed do
        local id = removed[i]
        local netId = Props[id] and Props[id].netId
        Props[id] = nil
        broadcast('eks_scenemanager:propRemove', id)
        if netId then
            broadcast('eks_scenemanager:deleteNetEntity', netId)
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source

    local removedZones = {}
    for id, z in pairs(Zones) do
        if z.owner == src then removedZones[#removedZones+1] = id end
    end
    for i = 1, #removedZones do
        Zones[removedZones[i]] = nil
        broadcast('eks_scenemanager:zoneRemove', removedZones[i])
    end

    local removedProps = {}
    local removedNet = {}
    for id, pr in pairs(Props) do
        if pr.owner == src then
            removedProps[#removedProps+1] = id
            removedNet[#removedNet+1] = pr.netId
        end
    end
    for i = 1, #removedProps do
        Props[removedProps[i]] = nil
        broadcast('eks_scenemanager:propRemove', removedProps[i])
    end
    for i = 1, #removedNet do
        if removedNet[i] then
            broadcast('eks_scenemanager:deleteNetEntity', removedNet[i])
        end
    end
end)

RegisterNetEvent('eks_scenemanager:deleteNetEntity', function(netId) end)


RegisterNetEvent('eks_scenemanager:laneToggle', function(coords, closed)
    local src = source
    if type(coords) ~= 'table' then return end
    local c = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 }
    local key = ('%.2f:%.2f:%.2f'):format(c.x, c.y, c.z)

    if LaneBlocks[key] then
        LaneBlocks[key].closed = closed and true or false
    else
        LaneBlocks[key] = { owner = src, coords = c, closed = closed and true or false }
    end

    TriggerClientEvent('eks_scenemanager:laneUpsert', -1, LaneBlocks[key])
end)
