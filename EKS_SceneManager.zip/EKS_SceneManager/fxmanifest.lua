fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS Scene Manager'
author 'Echo Kilo Studios'
description 'Traffic zones + scene equipment placement'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

dependency 'ox_lib'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}